library(shiny)
library(stats)
library(gplots)
library(VennDiagram)
# Define server logic for random distribution application
#
shinyServer(function(input, output) {
  #
  WeiEnPlot <- function(){
    A = 1:150
    B = c(121:170,300:320)
    C = c(20:40,141:200)
    T<-venn.diagram(list(等渗尿=A,低血压=B,静脉炎=C),filename=NULL
                    ,lwd=1,lty=2,col=c('red','green','blue')
                    ,fill=c('red','green','blue')
                    ,cat.col=c('red','green','blue')
                    ,reverse=TRUE)
    grid.draw(T)}
  #
  drugData0<- eventReactive(input$submit, {
    inFile <- input$file1
    if (is.null(inFile))
      return(NULL)
    else drugData<-read.csv(inFile$datapath, header=T)
    drugData0<-drugData[,2:15]/input$DrugNum
    drugData0<-cbind(drugData[1],drugData0)
    return(drugData0)
  }, ignoreNULL = FALSE)
  #
  blankData0<- eventReactive(input$submit, {
    inFile <- input$file2
    if (is.null(inFile))
      return(NULL)
    else blankData<-read.csv(inFile$datapath, header=T)
    blankData0<-blankData[,2:15]/input$BlankNum
    blankData0<-cbind(blankData[1],blankData0)
    return(blankData0)
  }, ignoreNULL = FALSE)
  #
  data0<-reactive({
    data0<-drugData0()[,2:15]/blankData0()[,2:15]
    data0<-as.matrix(data0)
    return(data0)
  })
  #
  RR<-reactive({
    RR<-NULL
    for(i in 1:27){
      RR<-rbind(RR,mean(data0()[i,]))}
    names<-blankData0()[,1]
    names0<-'RR'
    dimnames(RR)=list(names,names0)
    return(RR)
  })
  #
  lower<-reactive({
    lower<-NULL
    for(i in 1:27){
      lower<-rbind(lower,t.test(data0()[i,])$conf.int[1])}
    return(lower)
  })
  #
  upper<-reactive({
    upper<-NULL
    for(i in 1:27){
      upper<-rbind(upper,t.test(data0()[i,])$conf.int[2])}
    return(upper)
  })
  #
  data1<-reactive({
    data1<-drugData0()[,2:15]-blankData0()[,2:15]
    data1<-as.matrix(data1)
    return(data1)
  })
  #
  RD<-reactive({
    RD<-NULL
    for(i in 1:27){
      RD<-rbind(RD,mean(data1()[i,]))}
    names<-blankData0()[,1]
    names0<-'RD'
    dimnames(RD)=list(names,names0)
    return(RD)
  })
  re<-reactive({
    re<-as.matrix(drugData0()[,15])
    re<-rbind(re,as.matrix(blankData0()[,15]))
    return(re)
  })
  #
  p_value<-reactive({
    p_value<-NULL
    for(i in 1:27){
      p_value<-rbind(p_value,t.test(data1()[i,])$p.value)}
    p_value<--log10(p_value)
    return(p_value)
  })
  ##
  SengLinPlot<-function(){
    tryCatch({
      par(mfrow=c(2,1))
      plot(blankData0()[,15],pch = 21, bg = "red", main="森林图（△试验组，○对照组）", xlab="",ylab="发生率",xaxt="n")
      axis(1, at=1:27,labels=row.names(RR()),las=2)
      points(drugData0()[,15], pch=24,bg="blue")
      abline(v=1:27,lty=3)
      barplot2(t(RR()), plot.ci=TRUE,horiz =F,cex.axis = 0.5, ci.l=t(lower()), ci.u=t(upper()), col='#FFFFFF',border = '#FFFFFF',xpd=FALSE,  ylab="relative risk with 95% CL",las=2)
      abline(h=1,lty=3)}, warning = function ( w ) {""})
  }
  output$SengLinPlot <- renderPlot({
    #senglinPlot(RR(),lower(),upper(),blankData0(),drugData0())
    SengLinPlot()
  })
  ##
  HuoShanPlot<-function(){
    tryCatch({
      col<-heat.colors(54, alpha = 1) 
      cex.max<-12
      cex.min<-3
      a<-(cex.max-cex.min)/(max(re())-min(re()))
      b<-cex.min-a*min(re())
      cex2<-a*re()+b
      plot(RD(),p_value(),col=col,cex=cex2,pch=16,xlab="Risk Difference",ylab ="-log10(Raw P_value)",main=list('火山图',cex=0.8))
      #legend("topleft",legend=row.names(RR),pch=16,col=col,bty="n",cex=0.8,ncol=5)
      text(x=RD(),y=p_value(),labels=row.names(RD()),cex=0.5)
      abline(v=0,lty=3)
      abline(h=1.30103,lty=3)},warning = function ( w ) {""},error=function ( e ) {""})
  }
  output$HuoShanPlot <- renderPlot({
    #senglinPlot(RR(),lower(),upper(),blankData0(),drugData0())
    HuoShanPlot()
  })
  output$WeiEnPlot <- renderPlot({
    WeiEnPlot()})
  ##
  output$downloadPlot <- downloadHandler(
    filename = function() { paste(input$PlotSet, '.csv', sep='') },
    content = function(file) {
      if(input$PlotSet=="森林图"){
        data<-cbind(RR(),lower=lower(),upper=upper(),fileEncoding = "utf-8")
        write.csv(data,file)
      }
      if(input$PlotSet=="火山图"){
        data<-cbind(RD(),p_value())
        write.csv(data,file )
      }
      if(input$PlotSet=="韦恩图"){
        data<-cbind(RR(),lower(),upper())
        write.csv(data,file )
      }
    }
  )
})
