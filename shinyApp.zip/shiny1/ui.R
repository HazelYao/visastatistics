library(shiny)
library(shinydashboard)
options(shiny.maxRequestSize=30*1024^2)
dashboardPage( 
  dashboardHeader(title = "www.visastatistics.com"),  
  dashboardSidebar(
    
    
    fileInput('file1', '上传试验组数据表（.CSV）',
              accept=c('text/csv', 
                       'text/comma-separated-values,text/plain',
                       '.csv')),
    numericInput("DrugNum", "试验组的总人数", 10),
    br(),
    fileInput('file2', '上传对照组数据表（.CSV）',
              accept=c('text/csv', 
                       'text/comma-separated-values,text/plain',
                       '.csv')),
    numericInput("BlankNum", "对照组的总人数", 10),
    actionButton("submit", "提交"),
    br(),
    selectInput("PlotSet", "选择下载的数据：", 
                choices = c("森林图", "火山图", "韦恩图")),
    downloadButton('downloadPlot', 'Download')
  ),  
  dashboardBody(
    
    tabsetPanel(type = "tabs", 
                tabPanel("森林图", plotOutput("SengLinPlot")), 
                tabPanel("火山图", plotOutput("HuoShanPlot")), 
                tabPanel("韦恩图", plotOutput("WeiEnPlot"))
    )
      )
  )
